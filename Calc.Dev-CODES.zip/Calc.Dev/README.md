# Calc.Dev (Beta v0.4)

## NEW UPDATE

- _New language option (DE)_
- _I fixed the issues in Launcher.py and made a few minor tweaks._
- _Bug fix_

## 📜 License

- This project is licensed under the MIT License. This means the code can be freely used and modified, but the software is provided “as is” and no warranties are provided.

Language Support This program offers two language options.

- Turkish interface,
- English interface,
- German interface

## 🤝 Contribute

This project is open to development! If you find a bug or want to add a new feature:

- Fork this repository.
- Create a new feature branch.
- Commit your changes and submit a Pull Request.

## How to use

- Install Python: Make sure Python 3.x is installed on your computer.
- Select the language
- Install the Library: Open the terminal (CMD or VS Code Terminal) and type the following command:

'pip install colorama
