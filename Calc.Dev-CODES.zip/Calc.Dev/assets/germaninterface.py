from colorama import Fore, Style, init
import math
from datetime import datetime
import os
import traceback
init(autoreset=True)


FILE_PATH = os.path.dirname(os.path.abspath(__file__))
LOG_FILE = os.path.join(FILE_PATH, "Rechner_log.txt")

try:
    while True:
        CALCULATOR = Fore.CYAN + "=== RECHNER ==="
        print(CALCULATOR)
        
        num1 = float(input(Fore.GREEN + "Geben Sie die erste Zahl ein: "))
        num2 = float(input(Fore.GREEN + "Geben Sie die zweite Zahl ein: "))
        
        
        with open(LOG_FILE, "a", encoding="utf-8") as log_file:
            log_file.write(f"{datetime.now()}: Zahl {num1} und {num2} wurden eingegeben.\n")
        
        print(Fore.RED + "Wählen Sie die gewünschte Aktion aus:")
        print(Fore.CYAN + "1. Zusatz")    
        print(Fore.CYAN + "2. Subtraktion")    
        print(Fore.CYAN + "3. Multiplikation")
        print(Fore.CYAN + "4. Abteilung")
        print(Fore.CYAN + "5. Quadratwurzel")
        print(Fore.CYAN + "6. Potenzieren")
        print(Fore.CYAN + "7. Fakultät")
        print(Fore.CYAN + "8. Modulo")
        
        choice = input("Treffen Sie Ihre Wahl (1/2/3/4/5/6/7/8): ")
        
        if choice == '1':
            result = num1 + num2
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '2':
            result = num1 - num2
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '3':
            result = num1 * num2
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '4':
            if num2 == 0:
                print(Fore.RED + "Error: A number cannot be divided by zero!")
                continue
            result = num1 / num2
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '5':
            result = math.sqrt(num1)
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '6':
            result = math.pow(num1, num2)
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '7':
            result = math.factorial(int(num1))
            print(Fore.MAGENTA + "Ergebnis: ", result)
        elif choice == '8':
            result = num1 % num2
            print(Fore.MAGENTA + "Ergebnis: ", result)
        else:
            print(Fore.RED + "Ungültige Auswahl! Bitte wählen Sie eine Funktion aus dem Menü aus.")
            continue 
            
        
        with open(LOG_FILE, "a", encoding="utf-8") as log_file:
            log_file.write(f"{datetime.now()}: Ergebnis {result} wurde berechnet.\n")
            
        exit_choice = input(Fore.YELLOW + "Möchten Sie das Programm beenden? (J/N): ")
        if exit_choice.upper() == 'J':
            print(Fore.GREEN + "Den Taschenrechner beenden...")
            break
        elif exit_choice.upper() == 'N':
            print(Fore.GREEN + "Weiter mit dem Taschenrechner...\n")

except Exception as e:
    print(Fore.RED + "\nEs ist ein unerwarteter Fehler aufgetreten!")
    print(Fore.RED + "Fehlerdetails:")
    traceback.print_exc()
    input(Fore.YELLOW + "\nDrücken Sie die Eingabetaste, um das Fenster zu schließen...")