from colorama import Fore, init, Style
import os
import time

init(autoreset=True)

logo = f"""{Fore.YELLOW}
  _____             _______                _    
 |  __ \           |__   __|              | |   
 | |  | | _____   __  | | ___  _ __  _ __| | __
 | |  | |/ _ \ \ / /  | |/ _ \| '__| '__| |/ /
 | |__| |  __/\ V /   | | (_) | |  | |  |   < 
 |_____/ \___| \_/    |_|\___/|_|  |_|  |_|\_\\
{Fore.CYAN}       >> Calc.Dev <<
"""
try:
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        print(logo)
    
        dil = input(Fore.CYAN + "Dil seçin / select language (tr/en/de): ").lower().strip()

        if dil == "tr":
            from assets import turkishinterface as ui
            break
        
        elif dil == "en":
            from assets import englishinterface as ui
            break
        
        elif dil == "de":
            from assets import germaninterface as ui
            break
        
        else:
            print(Fore.RED + '\nInvalid input! Please try entering "tr", "en" or "de".')
            time.sleep(2)
except Exception as e:
    print("Some of the files required for the program to run are missing or have been deleted. Please download them again from GitHub.")
    time.sleep(20)
        

os.system('cls' if os.name == 'nt' else 'clear')
ui.baslat()
